# SOULSTEC — NIMBO Climate Intelligence

Sistema local de inteligência meteorológica baseado em dados reais da Open-Meteo.

## O que existe nesta versão

- FastAPI + Uvicorn no backend.
- Integração real com Open-Meteo Forecast API.
- Geocodificação real com Open-Meteo Geocoding API.
- Dados atuais e previsão horária de 3 dias.
- Janela operacional das próximas 12 horas.
- Risk Engine transparente e baseado em regras.
- Confidence Engine de 0 a 100, sem chamar o score de probabilidade.
- Explanation Engine.
- Forecast Engine separado.
- Dashboard responsivo.
- Chart.js para gráficos.
- Leaflet + OpenStreetMap para mapa.
- Tratamento de erros e estado de conexão.
- Atualização manual e automática a cada 5 minutos.
- Testes automatizados.

## Arquitetura

```text
SOULSTEC_NIMBO_CLIMATE_INTELLIGENCE/
├── backend/
│   ├── app.py
│   ├── nimbo/
│   │   ├── risk.py
│   │   ├── confidence.py
│   │   ├── explanation.py
│   │   └── forecast.py
│   ├── services/
│   │   └── weather.py
│   └── tests/
│       └── test_nimbo.py
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── data/
├── requirements.txt
├── .gitignore
└── README.md
```

## Requisitos

- Python 3.14
- Internet para consultar Open-Meteo, Chart.js e Leaflet/OpenStreetMap

## 1. Abrir no VS Code

Abra a pasta `SOULSTEC_NIMBO_CLIMATE_INTELLIGENCE`.

## 2. Criar ambiente virtual

### Windows PowerShell

```powershell
py -3.14 -m venv .venv
.\.venv\Scripts\Activate.ps1
```

Se o comando `py -3.14` não existir, use:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### Windows CMD

```cmd
py -3.14 -m venv .venv
.venv\Scripts\activate
```

## 3. Instalar dependências

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 4. Executar

Na raiz do projeto:

```bash
uvicorn backend.app:app --reload
```

Abra:

```text
http://127.0.0.1:8000
```

A interface já é servida pelo FastAPI. Não é necessário abrir `index.html` diretamente.

## 5. Testar

```bash
pytest -q
```

## Endpoints

- `GET /api`
- `GET /health`
- `GET /geocode?city=São Paulo`
- `GET /weather?latitude=-23.5505&longitude=-46.6333`
- `GET /analysis?latitude=-23.5505&longitude=-46.6333`
- `GET /forecast?latitude=-23.5505&longitude=-46.6333`
- `GET /intelligence?latitude=-23.5505&longitude=-46.6333`

Documentação automática do FastAPI:

```text
http://127.0.0.1:8000/docs
```


## Deploy no Vercel

Esta versão já possui um `app.py` na raiz que aponta para `backend.app:app`, permitindo que o Vercel detecte o FastAPI automaticamente. O Python está fixado em 3.14 por meio de `.python-version`.

### Opção 1 — GitHub + painel do Vercel

1. Envie **esta pasta inteira** para um repositório no GitHub.
2. No Vercel, escolha **Add New Project / Import Project** e selecione o repositório.
3. Deixe a **Root Directory** como a raiz do projeto, onde estão `app.py` e `requirements.txt`.
4. Não configure `npm run build` nem `dist`: este projeto é FastAPI + frontend servido pelo próprio FastAPI.
5. Faça o deploy.

### Opção 2 — Vercel CLI

Na raiz do projeto:

```bash
npm install -g vercel
vercel login
vercel
```

Depois que a versão de teste funcionar:

```bash
vercel --prod
```

O Vercel detecta o `app` exportado por `app.py` e executa o FastAPI como uma Vercel Function.

### Importante

Não envie `.venv/` para o GitHub. O Vercel instala as dependências usando `requirements.txt`.

O NIMBO continua consultando Open-Meteo e RainViewer em tempo de execução, então o projeto publicado precisa ter acesso à internet.

## Fonte dos dados

A fonte meteorológica principal é a Open-Meteo. Os valores exibidos não são inventados pelo NIMBO.

O NIMBO interpreta os valores recebidos com regras transparentes. O Risk Engine não é um modelo de machine learning e não representa uma previsão científica de desastres.

## Regras iniciais do Risk Engine

### Temperatura

- >= 40 °C → CRITICO
- >= 35 °C → ALTO
- >= 30 °C → MODERADO

### Precipitação

- >= 30 mm → CRITICO
- >= 10 mm → ALTO
- >= 5 mm → MODERADO

### Vento

- >= 80 km/h → CRITICO
- >= 50 km/h → ALTO
- >= 30 km/h → MODERADO

Também existe uma regra combinada para umidade >= 85% com precipitação >= 10 mm, sinalizando risco adicional de alagamento.

## Confidence Engine

O score de confiança é operacional, de 0 a 100. Ele considera:

1. disponibilidade das principais variáveis;
2. cobertura da previsão;
3. atualidade da consulta;
4. qualidade da fonte.

Ele NÃO é probabilidade de evento.

## Observação sobre APIs externas

O backend não precisa de API key para os serviços utilizados nesta primeira versão.

Se Open-Meteo ficar indisponível, o frontend informa:

`NIMBO TEMPORARILY OFFLINE`

e não exibe `undefined`, `null` ou `NaN`.

## Evolução futura

A arquitetura separa aquisição de dados, forecast, risco, confiança e explicação. Isso permite adicionar posteriormente histórico, sensores, modelos estatísticos, ML, data fusion e outros módulos da SOULSTEC sem misturar essas responsabilidades no frontend.


## Atualizações NIMBO 1.1

- Busca de localização em tempo real com debounce e cancelamento de consultas antigas.
- Geocodificação real pela Open-Meteo em português.
- Seleção de localização atualiza coordenadas, dashboard, forecast, risco, confiança, explicação e mapa.
- NIMBO Weather Map interativo com Leaflet/OpenStreetMap.
- Camada de precipitação por radar real da RainViewer.
- Camadas de temperatura e cobertura de nuvens construídas a partir de dados reais atuais da Open-Meteo.
- Camada de vento com velocidade e direção reais da Open-Meteo.
- Mapa atualiza as camadas meteorológicas sem reconstruir o mapa inteiro.

### Fontes do mapa

A camada base usa OpenStreetMap. O radar de precipitação utiliza o Weather Maps API da RainViewer, que disponibiliza dados de radar observados das últimas horas para uso pessoal/educacional. A aplicação exibe a atribuição exigida pelo serviço.

Temperatura, nuvens, velocidade e direção do vento são obtidas do modelo meteorológico da Open-Meteo em uma grade de coordenadas reais ao redor do mapa. Nenhum valor meteorológico é criado pelo frontend.

### Limitação importante da busca de uma letra

A API pública de geocodificação da Open-Meteo não retorna resultados para buscas de uma única letra. Por isso, a interface começa a preparar a busca imediatamente ao digitar, mas só envia uma consulta real a partir de 2 caracteres. Isso evita inventar resultados ou recorrer a uma fonte que proíba autocomplete automático.
