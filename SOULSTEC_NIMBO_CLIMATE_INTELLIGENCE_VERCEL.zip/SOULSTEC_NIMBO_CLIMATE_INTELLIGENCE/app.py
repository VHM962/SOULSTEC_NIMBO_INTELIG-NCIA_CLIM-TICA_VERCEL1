"""Vercel entrypoint for SOULSTEC NIMBO.

The actual FastAPI application remains in backend/app.py so local development
and the existing project architecture stay unchanged.
"""

from backend.app import app

__all__ = ["app"]
