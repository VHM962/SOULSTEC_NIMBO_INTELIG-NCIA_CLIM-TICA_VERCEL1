from fastapi.testclient import TestClient

from backend.app import app
from backend.nimbo.confidence import calculate
from backend.nimbo.forecast import build_forecast
from backend.nimbo.risk import analyze_current


def test_risk_critical_temperature():
    result = analyze_current(40, 0, 0, 50)
    assert result.level == "CRITICO"
    assert result.score >= 100


def test_risk_combination():
    result = analyze_current(28, 12, 55, 90)
    assert result.level in {"ALTO", "CRITICO"}
    assert len(result.risks) >= 2


def test_confidence_classification():
    result = calculate(
        current={
            "temperature_2m": 25,
            "relative_humidity_2m": 60,
            "precipitation": 0,
            "wind_speed_10m": 10,
        },
        hourly={
            "time": [f"2026-01-01T{i:02d}:00" for i in range(12)]
        },
    )
    assert 0 <= result["score"] <= 100
    assert result["classification"] == "MUITO_ALTA"


def test_forecast_uses_supplied_values():
    hourly = {
        "time": [f"2026-01-01T{i:02d}:00" for i in range(13)],
        "temperature_2m": list(range(20, 33)),
        "relative_humidity_2m": [60] * 13,
        "precipitation": [0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
        "wind_speed_10m": [10] * 13,
        "weather_code": [0] * 13,
    }
    result = build_forecast(hourly, hours=12)
    assert result["hours_analyzed"] == 12
    assert result["extremes"]["maximum_temperature"]["value"] == 31


def test_api_root():
    client = TestClient(app)
    response = client.get("/api")
    assert response.status_code == 200
    assert response.json()["module"] == "NIMBO"


def test_health():
    client = TestClient(app)
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "OPERATIONAL"
