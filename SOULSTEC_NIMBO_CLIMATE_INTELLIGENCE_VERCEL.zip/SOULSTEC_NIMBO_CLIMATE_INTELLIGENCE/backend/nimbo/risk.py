"""Transparent rule-based risk engine for NIMBO."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


LEVEL_ORDER = {"BAIXO": 0, "MODERADO": 1, "ALTO": 2, "CRITICO": 3}


@dataclass
class RiskResult:
    level: str
    score: int
    risks: list[dict[str, Any]]
    factors: list[str]


def _level_from_thresholds(
    value: float | None,
    moderate: float,
    high: float,
    critical: float,
) -> tuple[str, int]:
    if value is None:
        return "BAIXO", 0
    if value >= critical:
        return "CRITICO", 100
    if value >= high:
        return "ALTO", 75
    if value >= moderate:
        return "MODERADO", 45
    return "BAIXO", 10


def analyze_current(
    temperature: float | None,
    precipitation: float | None,
    wind_speed: float | None,
    humidity: float | None,
) -> RiskResult:
    """Analyze current conditions with explicit, inspectable rules."""
    risks: list[dict[str, Any]] = []
    factors: list[str] = []
    scores: list[int] = []

    temp_level, temp_score = _level_from_thresholds(temperature, 30, 35, 40)
    rain_level, rain_score = _level_from_thresholds(precipitation, 5, 10, 30)
    wind_level, wind_score = _level_from_thresholds(wind_speed, 30, 50, 80)

    checks = [
        ("TEMPERATURA", temp_level, temp_score, temperature, "°C"),
        ("PRECIPITAÇÃO", rain_level, rain_score, precipitation, "mm"),
        ("VENTO", wind_level, wind_score, wind_speed, "km/h"),
    ]

    for name, level, score, value, unit in checks:
        if value is None:
            continue
        scores.append(score)
        if level != "BAIXO":
            risks.append(
                {
                    "type": name,
                    "level": level,
                    "value": round(float(value), 1),
                    "unit": unit,
                }
            )
            factors.append(f"{name.lower()} em nível {level.lower()}")

    if humidity is not None and humidity >= 85 and precipitation is not None and precipitation >= 10:
        risks.append(
            {
                "type": "ALAGAMENTO",
                "level": "ALTO",
                "value": round(float(precipitation), 1),
                "unit": "mm",
            }
        )
        factors.append("umidade muito alta combinada com chuva intensa")
        scores.append(80)

    max_level = "BAIXO"
    if risks:
        max_level = max((r["level"] for r in risks), key=lambda x: LEVEL_ORDER[x])

    score = min(100, max(scores) if scores else 0)

    # Combination rule: two simultaneous elevated hazards increase operational score.
    elevated_count = sum(1 for r in risks if r["level"] in {"ALTO", "CRITICO"})
    if elevated_count >= 2:
        score = min(100, score + 10)
        if max_level == "MODERADO":
            max_level = "ALTO"

    return RiskResult(
        level=max_level,
        score=int(score),
        risks=risks,
        factors=factors,
    )


def analyze_forecast(hours: list[dict[str, Any]]) -> RiskResult:
    """Analyze a forecast window using the same transparent thresholds."""
    if not hours:
        return RiskResult("BAIXO", 0, [], [])

    max_temp = max((h.get("temperature_2m") for h in hours if h.get("temperature_2m") is not None), default=None)
    max_rain = max((h.get("precipitation") for h in hours if h.get("precipitation") is not None), default=None)
    max_wind = max((h.get("wind_speed_10m") for h in hours if h.get("wind_speed_10m") is not None), default=None)
    max_humidity = max((h.get("relative_humidity_2m") for h in hours if h.get("relative_humidity_2m") is not None), default=None)

    result = analyze_current(max_temp, max_rain, max_wind, max_humidity)
    return result
