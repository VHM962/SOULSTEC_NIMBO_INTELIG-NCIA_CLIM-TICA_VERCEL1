"""Forecast interpretation module. It never invents meteorological values."""

from __future__ import annotations

from typing import Any

from .risk import analyze_forecast


def _value_at(
    data: dict[str, Any],
    field: str,
    index: int,
) -> float | None:
    values = data.get(field) or []
    if index >= len(values):
        return None
    value = values[index]
    return float(value) if value is not None else None


def build_forecast(hourly: dict[str, Any], hours: int = 12) -> dict[str, Any]:
    times = hourly.get("time") or []
    limit = min(hours, len(times))

    items: list[dict[str, Any]] = []
    for i in range(limit):
        items.append(
            {
                "time": times[i],
                "temperature_2m": _value_at(hourly, "temperature_2m", i),
                "relative_humidity_2m": _value_at(hourly, "relative_humidity_2m", i),
                "precipitation": _value_at(hourly, "precipitation", i),
                "wind_speed_10m": _value_at(hourly, "wind_speed_10m", i),
                "weather_code": _value_at(hourly, "weather_code", i),
            }
        )

    risk = analyze_forecast(items)

    def peak(field: str) -> tuple[float | None, str | None]:
        valid = [(x[field], x["time"]) for x in items if x.get(field) is not None]
        if not valid:
            return None, None
        value, time = max(valid, key=lambda pair: pair[0])
        return value, time

    max_temp, max_temp_time = peak("temperature_2m")
    max_rain, max_rain_time = peak("precipitation")
    max_wind, max_wind_time = peak("wind_speed_10m")

    trend_summary = "Tendência estável no período analisado."
    if len(items) >= 2:
        first_temp = items[0].get("temperature_2m")
        last_temp = items[-1].get("temperature_2m")
        first_wind = items[0].get("wind_speed_10m")
        last_wind = items[-1].get("wind_speed_10m")

        parts = []
        if first_temp is not None and last_temp is not None:
            delta = last_temp - first_temp
            if delta >= 1.5:
                parts.append("temperatura em alta")
            elif delta <= -1.5:
                parts.append("temperatura em queda")
        if first_wind is not None and last_wind is not None:
            delta = last_wind - first_wind
            if delta >= 10:
                parts.append("vento ganhando intensidade")
            elif delta <= -10:
                parts.append("vento perdendo intensidade")

        if parts:
            trend_summary = "Tendência: " + " e ".join(parts) + "."

    return {
        "hours_analyzed": limit,
        "items": items,
        "risk": {
            "level": risk.level,
            "score": risk.score,
            "risks": risk.risks,
            "factors": risk.factors,
        },
        "extremes": {
            "maximum_temperature": {"value": max_temp, "time": max_temp_time},
            "maximum_precipitation": {"value": max_rain, "time": max_rain_time},
            "maximum_wind": {"value": max_wind, "time": max_wind_time},
        },
        "trend_summary": trend_summary,
    }
