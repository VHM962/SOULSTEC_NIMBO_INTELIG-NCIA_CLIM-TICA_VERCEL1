"""Operational confidence scoring. This is NOT event probability."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


def classify(score: int) -> str:
    if score >= 90:
        return "MUITO_ALTA"
    if score >= 75:
        return "ALTA"
    if score >= 50:
        return "MODERADA"
    if score >= 25:
        return "BAIXA"
    return "MUITO_BAIXA"


def calculate(
    *,
    current: dict[str, Any] | None,
    hourly: dict[str, Any] | None,
    source: str = "Open-Meteo",
    fetched_at: datetime | None = None,
) -> dict[str, Any]:
    """Calculate a transparent 0-100 operational confidence score."""
    score = 0
    factors: list[dict[str, Any]] = []

    current_fields = ["temperature_2m", "relative_humidity_2m", "precipitation", "wind_speed_10m"]
    current_available = sum(
        current and current.get(field) is not None for field in current_fields
    )
    current_points = round(25 * current_available / len(current_fields))
    score += current_points
    factors.append(
        {
            "name": "Dados disponíveis",
            "score": current_points,
            "detail": f"{current_available}/{len(current_fields)} variáveis principais disponíveis",
        }
    )

    hourly_times = len((hourly or {}).get("time", []))
    hourly_points = 25 if hourly_times >= 12 else round(25 * hourly_times / 12)
    score += hourly_points
    factors.append(
        {
            "name": "Cobertura da previsão",
            "score": hourly_points,
            "detail": f"{hourly_times} horários disponíveis",
        }
    )

    freshness_points = 25
    if fetched_at:
        age_seconds = max(0, (datetime.now(timezone.utc) - fetched_at).total_seconds())
        if age_seconds > 900:
            freshness_points = 15
        if age_seconds > 3600:
            freshness_points = 5
    score += freshness_points
    factors.append(
        {
            "name": "Atualidade",
            "score": freshness_points,
            "detail": "Dados consultados em tempo real" if freshness_points == 25 else "Dados podem estar desatualizados",
        }
    )

    source_points = 25 if source == "Open-Meteo" else 15
    score += source_points
    factors.append(
        {
            "name": "Qualidade da fonte",
            "score": source_points,
            "detail": source,
        }
    )

    final = min(100, max(0, score))
    return {
        "score": final,
        "classification": classify(final),
        "factors": factors,
        "is_probability": False,
        "note": "Confiança operacional da análise; não representa probabilidade de ocorrência de um evento.",
    }
