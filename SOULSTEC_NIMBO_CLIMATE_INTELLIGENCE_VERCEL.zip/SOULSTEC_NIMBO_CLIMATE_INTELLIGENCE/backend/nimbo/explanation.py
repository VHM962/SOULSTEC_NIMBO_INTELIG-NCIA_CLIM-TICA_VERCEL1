"""Human-readable explanations generated from the rule engine output."""

from __future__ import annotations

from typing import Any


def build(
    *,
    risk: dict[str, Any],
    current: dict[str, Any],
    forecast: dict[str, Any],
    confidence: dict[str, Any],
) -> dict[str, Any]:
    risks = risk.get("risks", [])
    factors = risk.get("factors", [])

    if not risks:
        summary = "Não foram identificadas condições meteorológicas significativas pelos limiares operacionais atuais."
    elif len(risks) == 1:
        item = risks[0]
        summary = f"Risco {risk['level'].lower()} associado principalmente a {item['type'].lower()}."
    else:
        names = ", ".join(item["type"].lower() for item in risks[:3])
        summary = f"Risco {risk['level'].lower()} devido à combinação de {names}."

    observations = []
    for field, label, unit in [
        ("temperature_2m", "temperatura", "°C"),
        ("relative_humidity_2m", "umidade", "%"),
        ("precipitation", "precipitação", "mm"),
        ("wind_speed_10m", "vento", "km/h"),
    ]:
        value = current.get(field)
        if value is not None:
            observations.append(f"{label}: {float(value):.1f}{unit}")

    forecast_text = forecast.get("trend_summary")
    if forecast_text:
        observations.append(forecast_text)

    return {
        "summary": summary,
        "factors": factors,
        "observations": observations,
        "confidence": {
            "score": confidence.get("score"),
            "classification": confidence.get("classification"),
        },
    }
