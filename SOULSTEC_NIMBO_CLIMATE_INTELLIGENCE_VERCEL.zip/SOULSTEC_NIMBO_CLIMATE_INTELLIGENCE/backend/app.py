from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from backend.nimbo.confidence import calculate as calculate_confidence
from backend.nimbo.explanation import build as build_explanation
from backend.nimbo.forecast import build_forecast
from backend.nimbo.risk import analyze_current
from backend.services.weather import (
    WeatherAPIError,
    geocode_city,
    get_map_grid,
    get_radar_metadata,
    get_weather,
    normalize_location,
)


BASE_DIR = Path(__file__).resolve().parent.parent
FRONTEND_DIR = BASE_DIR / "frontend"

app = FastAPI(
    title="SOULSTEC NIMBO Climate Intelligence",
    version="1.1.0",
    description="NIMBO — Neural Intelligence for Meteorological & Biospheric Operations. Real-time weather intelligence using real external data.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


def validate_coordinates(latitude: float, longitude: float) -> None:
    if not -90 <= latitude <= 90:
        raise HTTPException(status_code=422, detail="Latitude deve estar entre -90 e 90.")
    if not -180 <= longitude <= 180:
        raise HTTPException(status_code=422, detail="Longitude deve estar entre -180 e 180.")


def fetch(latitude: float, longitude: float) -> dict[str, Any]:
    validate_coordinates(latitude, longitude)
    try:
        return get_weather(latitude, longitude)
    except WeatherAPIError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


def current_payload(data: dict[str, Any]) -> dict[str, Any]:
    current = data.get("current", {})
    return {
        "time": current.get("time"),
        "temperature_2m": current.get("temperature_2m"),
        "relative_humidity_2m": current.get("relative_humidity_2m"),
        "precipitation": current.get("precipitation"),
        "wind_speed_10m": current.get("wind_speed_10m"),
        "wind_direction_10m": current.get("wind_direction_10m"),
        "cloud_cover": current.get("cloud_cover"),
        "weather_code": current.get("weather_code"),
    }


@app.get("/api")
def api_root() -> dict[str, str]:
    return {
        "system": "SOULSTEC CLIMATE INTELLIGENCE",
        "module": "NIMBO",
        "status": "OPERATIONAL",
    }


@app.get("/health")
def health() -> dict[str, str]:
    return {
        "status": "OPERATIONAL",
        "nimbo": "ONLINE",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@app.get("/geocode")
def geocode(city: str = Query(..., min_length=2, max_length=100)) -> dict[str, Any]:
    try:
        results = geocode_city(city)
    except (WeatherAPIError, ValueError) as exc:
        status = 400 if isinstance(exc, ValueError) else 503
        raise HTTPException(status_code=status, detail=str(exc)) from exc
    return {
        "query": city,
        "results": results,
        "source": "Open-Meteo Geocoding API",
    }


@app.get("/weather")
def weather(
    latitude: float = Query(...),
    longitude: float = Query(...),
) -> dict[str, Any]:
    data = fetch(latitude, longitude)
    return {
        "location": normalize_location(data),
        "current": current_payload(data),
        "units": data.get("current_units", {}),
        "source": "Open-Meteo",
    }


@app.get("/analysis")
def analysis(
    latitude: float = Query(...),
    longitude: float = Query(...),
) -> dict[str, Any]:
    data = fetch(latitude, longitude)
    current = current_payload(data)
    risk = analyze_current(
        current.get("temperature_2m"),
        current.get("precipitation"),
        current.get("wind_speed_10m"),
        current.get("relative_humidity_2m"),
    )
    fetched = datetime.fromisoformat(data["_nimbo_fetched_at"])
    confidence = calculate_confidence(
        current=current,
        hourly=data.get("hourly"),
        fetched_at=fetched,
    )
    return {
        "location": normalize_location(data),
        "current": current,
        "risk": {
            "level": risk.level,
            "score": risk.score,
            "risks": risk.risks,
            "factors": risk.factors,
        },
        "confidence": confidence,
        "source": "Open-Meteo",
    }


@app.get("/forecast")
def forecast(
    latitude: float = Query(...),
    longitude: float = Query(...),
) -> dict[str, Any]:
    data = fetch(latitude, longitude)
    return {
        "location": normalize_location(data),
        "forecast": build_forecast(data.get("hourly", {}), hours=12),
        "units": data.get("hourly_units", {}),
        "source": "Open-Meteo",
    }


@app.get("/intelligence")
def intelligence(
    latitude: float = Query(...),
    longitude: float = Query(...),
) -> dict[str, Any]:
    data = fetch(latitude, longitude)
    location = normalize_location(data)
    current = current_payload(data)
    forecast_data = build_forecast(data.get("hourly", {}), hours=12)
    risk = analyze_current(
        current.get("temperature_2m"),
        current.get("precipitation"),
        current.get("wind_speed_10m"),
        current.get("relative_humidity_2m"),
    )
    fetched = datetime.fromisoformat(data["_nimbo_fetched_at"])
    confidence = calculate_confidence(
        current=current,
        hourly=data.get("hourly"),
        fetched_at=fetched,
    )
    risk_dict = {
        "level": risk.level,
        "score": risk.score,
        "risks": risk.risks,
        "factors": risk.factors,
    }
    explanation = build_explanation(
        risk=risk_dict,
        current=current,
        forecast=forecast_data,
        confidence=confidence,
    )
    return {
        "system": "NIMBO",
        "status": "OPERATIONAL",
        "location": location,
        "current": current,
        "units": {
            **data.get("current_units", {}),
            **data.get("hourly_units", {}),
        },
        "risk": risk_dict,
        "confidence": confidence,
        "forecast": forecast_data,
        "explanation": explanation,
        "source": "Open-Meteo",
        "fetched_at": data["_nimbo_fetched_at"],
    }


@app.get("/map-grid")
def map_grid(
    latitude: float = Query(...),
    longitude: float = Query(...),
    span: float = Query(4.0, ge=0.5, le=15.0),
) -> dict[str, Any]:
    validate_coordinates(latitude, longitude)
    try:
        grid = get_map_grid(latitude, longitude, span=span, points=7)
    except WeatherAPIError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return {
        "center": {"latitude": latitude, "longitude": longitude},
        "grid": grid,
        "source": "Open-Meteo",
    }


@app.get("/radar")
def radar() -> dict[str, Any]:
    try:
        return get_radar_metadata()
    except WeatherAPIError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get("/", include_in_schema=False)
def frontend() -> FileResponse:
    return FileResponse(FRONTEND_DIR / "index.html")


app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")
