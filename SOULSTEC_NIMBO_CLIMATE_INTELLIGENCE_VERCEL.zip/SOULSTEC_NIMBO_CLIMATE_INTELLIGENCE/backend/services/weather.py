"""Real weather and geocoding integrations used by NIMBO."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import requests


BASE_URL = "https://api.open-meteo.com/v1/forecast"
GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search"
RAINVIEWER_URL = "https://api.rainviewer.com/public/weather-maps.json"
TIMEOUT = 12


class WeatherAPIError(RuntimeError):
    pass


def _request(url: str, params: dict[str, Any] | None = None) -> Any:
    try:
        response = requests.get(url, params=params, timeout=TIMEOUT)
        response.raise_for_status()
        payload = response.json()
        if not isinstance(payload, (dict, list)):
            raise WeatherAPIError("A API retornou um formato inesperado.")
        return payload
    except requests.RequestException as exc:
        raise WeatherAPIError("Não foi possível consultar o serviço externo.") from exc
    except ValueError as exc:
        raise WeatherAPIError("A API retornou uma resposta inválida.") from exc


def _normalise_location(result: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": result.get("id"),
        "name": result.get("name"),
        "latitude": result.get("latitude"),
        "longitude": result.get("longitude"),
        "elevation": result.get("elevation"),
        "timezone": result.get("timezone"),
        "feature_code": result.get("feature_code"),
        "country_code": result.get("country_code"),
        "country": result.get("country"),
        "admin1": result.get("admin1"),
        "admin2": result.get("admin2"),
        "population": result.get("population"),
    }


def geocode_city(name: str) -> list[dict[str, Any]]:
    name = " ".join(name.strip().split())
    if len(name) < 2:
        raise ValueError("Digite pelo menos 2 letras para pesquisar uma localização real.")

    data = _request(
        GEOCODING_URL,
        {
            "name": name,
            "count": 10,
            "language": "pt",
            "format": "json",
        },
    )

    results = [_normalise_location(item) for item in data.get("results", [])]

    # The API already ranks matches. This small deterministic pass prioritises
    # exact/prefix matches while keeping population as a useful tie-breaker.
    query_folded = name.casefold()
    results.sort(
        key=lambda item: (
            0 if str(item.get("name") or "").casefold() == query_folded else 1,
            0 if str(item.get("name") or "").casefold().startswith(query_folded) else 1,
            -(int(item.get("population") or 0)),
        )
    )
    return results


def get_weather(latitude: float, longitude: float) -> dict[str, Any]:
    params = {
        "latitude": latitude,
        "longitude": longitude,
        "current": ",".join(
            [
                "temperature_2m",
                "relative_humidity_2m",
                "precipitation",
                "wind_speed_10m",
                "wind_direction_10m",
                "cloud_cover",
                "weather_code",
            ]
        ),
        "hourly": ",".join(
            [
                "temperature_2m",
                "relative_humidity_2m",
                "precipitation",
                "wind_speed_10m",
                "wind_direction_10m",
                "cloud_cover",
                "weather_code",
            ]
        ),
        "forecast_days": 3,
        "timezone": "auto",
        "wind_speed_unit": "kmh",
        "precipitation_unit": "mm",
    }
    data = _request(BASE_URL, params)
    data["_nimbo_fetched_at"] = datetime.now(timezone.utc).isoformat()
    return data


def get_map_grid(latitude: float, longitude: float, span: float = 4.0, points: int = 7) -> list[dict[str, Any]]:
    """Fetch a small real-data weather grid in one Open-Meteo request."""
    span = max(0.5, min(float(span), 15.0))
    points = max(3, min(int(points), 9))

    lat_step = span / (points - 1)
    # Keep longitude spacing visually comparable to latitude at the selected latitude.
    cos_lat = max(0.25, abs(__import__("math").cos(__import__("math").radians(latitude))))
    lon_span = min(15.0, span / cos_lat)
    lon_step = lon_span / (points - 1)

    latitudes: list[float] = []
    longitudes: list[float] = []
    for row in range(points):
        lat = max(-89.0, min(89.0, latitude - span / 2 + row * lat_step))
        for col in range(points):
            lon = max(-179.0, min(179.0, longitude - lon_span / 2 + col * lon_step))
            latitudes.append(round(lat, 5))
            longitudes.append(round(lon, 5))

    data = _request(
        BASE_URL,
        {
            "latitude": ",".join(map(str, latitudes)),
            "longitude": ",".join(map(str, longitudes)),
            "current": ",".join(
                [
                    "temperature_2m",
                    "precipitation",
                    "wind_speed_10m",
                    "wind_direction_10m",
                    "cloud_cover",
                ]
            ),
            "timezone": "UTC",
            "wind_speed_unit": "kmh",
            "precipitation_unit": "mm",
        },
    )

    # Multiple coordinates return a JSON list. Keep the fallback defensive.
    records = data if isinstance(data, list) else [data]
    grid: list[dict[str, Any]] = []
    for record in records:
        current = record.get("current", {})
        grid.append(
            {
                "latitude": record.get("latitude"),
                "longitude": record.get("longitude"),
                "temperature_2m": current.get("temperature_2m"),
                "precipitation": current.get("precipitation"),
                "wind_speed_10m": current.get("wind_speed_10m"),
                "wind_direction_10m": current.get("wind_direction_10m"),
                "cloud_cover": current.get("cloud_cover"),
                "time": current.get("time"),
            }
        )
    return grid


def get_radar_metadata() -> dict[str, Any]:
    data = _request(RAINVIEWER_URL)
    radar = data.get("radar") or {}
    past = radar.get("past") or []
    if not past:
        raise WeatherAPIError("O serviço de radar não retornou uma imagem disponível.")
    frame = past[-1]
    host = str(data.get("host") or "").rstrip("/")
    path = str(frame.get("path") or "")
    if not host or not path:
        raise WeatherAPIError("Metadados de radar incompletos.")
    return {
        "host": host,
        "path": path,
        "time": frame.get("time"),
        "tile_template": f"{host}{path}/256/{{z}}/{{x}}/{{y}}/2/1_1.png",
        "source": "RainViewer",
        "max_native_zoom": 7,
    }


def normalize_location(data: dict[str, Any]) -> dict[str, Any]:
    return {
        "latitude": data.get("latitude"),
        "longitude": data.get("longitude"),
        "timezone": data.get("timezone"),
        "timezone_abbreviation": data.get("timezone_abbreviation"),
        "elevation": data.get("elevation"),
    }
