const state = {
  latitude: -23.5505,
  longitude: -46.6333,
  locationName: "São Paulo, Brasil",
  charts: {},
  map: null,
  marker: null,
  mapLayers: {
    precipitation: null,
    temperature: null,
    wind: null,
    clouds: null,
  },
  mapGridAbort: null,
  radarAbort: null,
  searchAbort: null,
  searchTimer: null,
  mapTimer: null,
  selectedLocation: null,
  lastRadarPath: null,
};

const $ = (id) => document.getElementById(id);

function safeNumber(value, decimals = 1) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return "—";
  return Number(value).toFixed(decimals);
}

function clamp(value, min, max) { return Math.min(max, Math.max(min, value)); }

function setConnection(status, label) {
  const badge = $("connectionBadge");
  badge.className = `status-badge ${status}`;
  $("connectionText").textContent = label;
}

function setLoading(show, text = "SYNCING...") {
  $("loadingOverlay").classList.toggle("hidden", !show);
  $("loadingText").textContent = text;
}

function showError(message) {
  const banner = $("errorBanner");
  banner.textContent = message;
  banner.classList.remove("hidden");
}

function clearError() {
  $("errorBanner").classList.add("hidden");
  $("errorBanner").textContent = "";
}

async function api(path, options = {}) {
  const response = await fetch(path, options);
  let payload = {};
  try { payload = await response.json(); } catch (_) {}
  if (!response.ok) throw new Error(payload.detail || "Não foi possível concluir a consulta.");
  return payload;
}

function updateLocationMeta(location) {
  const lat = safeNumber(location.latitude, 4);
  const lon = safeNumber(location.longitude, 4);
  const tz = location.timezone || "timezone indisponível";
  $("locationMeta").textContent = `${state.locationName} · ${lat}, ${lon} · ${tz}`;
  $("mapCoordinates").textContent = `${lat}, ${lon}`;
}

function weatherLabel(code) {
  const map = {0:"Céu limpo",1:"Predominantemente limpo",2:"Parcialmente nublado",3:"Nublado",45:"Névoa",48:"Névoa com geada",51:"Chuvisco",53:"Chuvisco",55:"Chuvisco intenso",61:"Chuva leve",63:"Chuva moderada",65:"Chuva forte",71:"Neve leve",73:"Neve moderada",75:"Neve forte",80:"Pancadas leves",81:"Pancadas moderadas",82:"Pancadas fortes",95:"Trovoada",96:"Trovoada com granizo",99:"Trovoada com granizo"};
  return map[code] || "Condição meteorológica";
}

function renderCurrent(data) {
  const current = data.current;
  $("temperature").textContent = safeNumber(current.temperature_2m);
  $("humidity").textContent = safeNumber(current.relative_humidity_2m, 0);
  $("rain").textContent = safeNumber(current.precipitation);
  $("wind").textContent = safeNumber(current.wind_speed_10m);
  $("temperatureTime").textContent = current.time ? `OBSERVADO ${current.time.replace("T", " ")}` : "DATA UNAVAILABLE";
  updateLocationMeta(data.location);
}

function riskColor(level) {
  if (level === "CRITICO") return "var(--red)";
  if (level === "ALTO") return "var(--amber)";
  if (level === "MODERADO") return "#e9c878";
  return "var(--green)";
}

function renderRisk(risk) {
  $("riskLevel").textContent = risk.level || "BAIXO";
  $("riskLevel").style.color = riskColor(risk.level);
  $("riskScore").querySelector("span").textContent = risk.score ?? "—";
  const pills = $("riskPills");
  pills.innerHTML = "";
  if (!risk.risks?.length) pills.innerHTML = `<span class="pill" style="color:var(--green)">SEM RISCO SIGNIFICATIVO</span>`;
  else risk.risks.forEach((item) => {
    const el = document.createElement("span");
    el.className = "pill";
    el.textContent = `${item.type} · ${item.level}`;
    el.style.color = riskColor(item.level);
    pills.appendChild(el);
  });
}

function renderConfidence(confidence) {
  $("confidenceScore").textContent = confidence.score ?? "—";
  $("confidenceClass").textContent = confidence.classification || "—";
  $("confidenceBar").style.width = `${confidence.score || 0}%`;
  const box = $("confidenceFactors");
  box.innerHTML = "";
  (confidence.factors || []).forEach((factor) => {
    const el = document.createElement("div");
    el.className = "factor";
    el.innerHTML = `<strong>${factor.name} · ${factor.score}/25</strong><span>${factor.detail}</span>`;
    box.appendChild(el);
  });
}

function chartOptions() {
  return { responsive:true, maintainAspectRatio:false, interaction:{mode:"index",intersect:false}, plugins:{legend:{display:false},tooltip:{backgroundColor:"#071014",borderColor:"rgba(126,211,221,.2)",borderWidth:1,titleColor:"#e8f4f5",bodyColor:"#9eb0b4"}},scales:{x:{ticks:{color:"#62767b",font:{size:9}},grid:{color:"rgba(126,211,221,.05)"}},y:{ticks:{color:"#62767b",font:{size:9}},grid:{color:"rgba(126,211,221,.06)"}}} };
}

function renderChart(id, label, values, labels, unit) {
  if (state.charts[id]) state.charts[id].destroy();
  state.charts[id] = new Chart($(id), {type:"line",data:{labels,datasets:[{label,data:values,borderColor:"#62e5e1",backgroundColor:"rgba(98,229,225,.07)",fill:true,tension:.34,pointRadius:2,pointHoverRadius:4,borderWidth:2}]},options:{...chartOptions(),plugins:{...chartOptions().plugins,tooltip:{...chartOptions().plugins.tooltip,callbacks:{label:(ctx)=>`${safeNumber(ctx.raw)} ${unit}`}}}}});
}

function renderForecast(forecast) {
  const items = forecast.items || [];
  const labels = items.map((x) => x.time ? x.time.slice(11,16) : "—");
  renderChart("temperatureChart","Temperatura",items.map((x)=>x.temperature_2m),labels,"°C");
  renderChart("rainChart","Precipitação",items.map((x)=>x.precipitation),labels,"mm");
  renderChart("windChart","Vento",items.map((x)=>x.wind_speed_10m),labels,"km/h");
  $("forecastTrend").textContent = forecast.trend_summary || "Tendência indisponível";
  renderTimeline(items);
}

function renderTimeline(items) {
  const timeline = $("timeline");
  timeline.innerHTML = "";
  items.slice(0,12).forEach((item,index)=>{
    const el=document.createElement("div"); el.className="timeline-item";
    el.innerHTML=`<div class="timeline-time">${index===0?"AGORA":`+${index}H`}</div><div class="timeline-temp">${safeNumber(item.temperature_2m)}°</div><div class="timeline-data">💧 ${safeNumber(item.precipitation)} mm<br>↝ ${safeNumber(item.wind_speed_10m)} km/h<br>${weatherLabel(item.weather_code)}</div>`;
    timeline.appendChild(el);
  });
}

function renderAlerts(risk, forecast) {
  const alerts=$("alerts"); alerts.innerHTML="";
  const items=risk.risks||[];
  if(!items.length){alerts.innerHTML=`<div class="alert"><div class="alert-icon">✓</div><div><strong>SEM ALERTAS OPERACIONAIS</strong><span>Não foram identificadas condições meteorológicas significativas pelos limiares atuais.</span></div></div>`;return;}
  items.forEach(item=>{const el=document.createElement("div");el.className="alert";el.innerHTML=`<div class="alert-icon">!</div><div><strong>${item.type} · ${item.level}</strong><span>Valor detectado: ${safeNumber(item.value)} ${item.unit||""}</span></div>`;alerts.appendChild(el);});
  const extremes=forecast.extremes||{};
  [["TEMPERATURA MÁXIMA",extremes.maximum_temperature],["CHUVA MÁXIMA",extremes.maximum_precipitation],["VENTO MÁXIMO",extremes.maximum_wind]].forEach(([name,peak])=>{if(!peak||peak.value==null)return;const el=document.createElement("div");el.className="alert";el.innerHTML=`<div class="alert-icon">⌁</div><div><strong>${name}</strong><span>${safeNumber(peak.value)} · ${peak.time||"horário indisponível"}</span></div>`;alerts.appendChild(el);});
}

function renderExplanation(explanation) {
  $("explanationSummary").textContent=explanation.summary||"Aguardando uma análise.";
  const factors=$("explanationFactors"), observations=$("explanationObservations"); factors.innerHTML=""; observations.innerHTML="";
  (explanation.factors||[]).forEach(f=>{const li=document.createElement("li");li.textContent=f;factors.appendChild(li);});
  (explanation.observations||[]).forEach(o=>{const li=document.createElement("li");li.textContent=o;observations.appendChild(li);});
}

function tempColor(value) {
  if (value == null) return "transparent";
  const t=clamp((Number(value)+5)/45,0,1);
  const hue=220-(220*t);
  return `hsla(${hue}, 90%, 55%, .34)`;
}
function cloudColor(value) {
  if(value==null)return"transparent";
  const alpha=.08+.34*(clamp(Number(value),0,100)/100);
  return `rgba(180,205,214,${alpha})`;
}
function windColor(value) {
  if(value==null)return"#62e5e1";
  const t=clamp(Number(value)/90,0,1);
  const hue=190-190*t;
  return `hsl(${hue}, 90%, 62%)`;
}
function rainLegendHTML() {
  return `<div class="legend-title">PRECIPITAÇÃO / RADAR</div><div class="legend-scale radar-scale"><i></i><i></i><i></i><i></i><i></i></div><div class="legend-labels"><span>baixa</span><span>moderada</span><span>forte</span><span>extrema</span></div><div class="legend-note">Radar observado · últimos 2h</div>`;
}
function dataLegendHTML(layer) {
  if(layer==="temperature") return `<div class="legend-title">TEMPERATURA</div><div class="legend-gradient temp-gradient"></div><div class="legend-labels"><span>frio</span><span>moderado</span><span>quente</span></div><div class="legend-note">Modelo Open-Meteo · condição atual</div>`;
  if(layer==="clouds") return `<div class="legend-title">COBERTURA DE NUVENS</div><div class="legend-gradient cloud-gradient"></div><div class="legend-labels"><span>0%</span><span>50%</span><span>100%</span></div><div class="legend-note">Modelo Open-Meteo · condição atual</div>`;
  return `<div class="legend-title">VENTO</div><div class="legend-gradient wind-gradient"></div><div class="legend-labels"><span>0</span><span>45</span><span>90+ km/h</span></div><div class="legend-note">Open-Meteo · direção e intensidade</div>`;
}

function clearDataLayers() {
  ["temperature","wind","clouds"].forEach(name=>{
    const layer=state.mapLayers[name];
    if(layer && state.map) state.map.removeLayer(layer);
    state.mapLayers[name]=null;
  });
}

function renderGridLayer(grid, type) {
  if(!state.map || !grid.length)return null;
  const latitudes=[...new Set(grid.map(p=>Number(p.latitude).toFixed(5)))].map(Number).sort((a,b)=>a-b);
  const longitudes=[...new Set(grid.map(p=>Number(p.longitude).toFixed(5)))].map(Number).sort((a,b)=>a-b);
  const lookup=new Map(grid.map(p=>[`${Number(p.latitude).toFixed(5)}|${Number(p.longitude).toFixed(5)}`,p]));
  const group=L.layerGroup();
  for(let r=0;r<latitudes.length-1;r++){
    for(let c=0;c<longitudes.length-1;c++){
      const p1=lookup.get(`${latitudes[r].toFixed(5)}|${longitudes[c].toFixed(5)}`);
      const p2=lookup.get(`${latitudes[r+1].toFixed(5)}|${longitudes[c].toFixed(5)}`);
      const p3=lookup.get(`${latitudes[r+1].toFixed(5)}|${longitudes[c+1].toFixed(5)}`);
      const p4=lookup.get(`${latitudes[r].toFixed(5)}|${longitudes[c+1].toFixed(5)}`);
      if(!p1||!p2||!p3||!p4)continue;
      const vals=[p1,p2,p3,p4].map(p=>Number(p[type])).filter(Number.isFinite);
      if(!vals.length)continue;
      const avg=vals.reduce((a,b)=>a+b,0)/vals.length;
      const color=type==="temperature"?tempColor(avg):cloudColor(avg);
      group.addLayer(L.rectangle([[latitudes[r],longitudes[c]],[latitudes[r+1],longitudes[c+1]]],{stroke:false,fillColor:color,fillOpacity:1,interactive:false}));
    }
  }
  return group;
}

function renderWindLayer(grid) {
  if(!state.map)return null;
  const group=L.layerGroup();
  grid.forEach(p=>{
    if(p.wind_speed_10m==null||p.wind_direction_10m==null)return;
    const speed=Number(p.wind_speed_10m), direction=Number(p.wind_direction_10m);
    const size=clamp(13+speed*.18,13,28);
    const html=`<div class="wind-arrow" style="transform:rotate(${direction}deg);color:${windColor(speed)};font-size:${size}px">↑</div>`;
    group.addLayer(L.marker([p.latitude,p.longitude],{icon:L.divIcon({className:"wind-marker",html,iconSize:[size,size],iconAnchor:[size/2,size/2]})}).bindTooltip(`${safeNumber(speed)} km/h · direção ${Math.round(direction)}°`,{direction:"top",offset:[0,-8]}));
  });
  return group;
}

function updateLegend() {
  const checks=[...document.querySelectorAll(".layer-toggle input")];
  const active=checks.find(c=>c.checked);
  $("mapLegend").innerHTML=active?(active.dataset.layer==="precipitation"?rainLegendHTML():dataLegendHTML(active.dataset.layer)):`<div class="legend-title">MAPA BASE</div><div class="legend-note">Ative uma camada meteorológica.</div>`;
}

async function loadRadarLayer() {
  if(!state.map)return;
  try{
    if(state.radarAbort)state.radarAbort.abort();
    state.radarAbort=new AbortController();
    const data=await api("/radar",{signal:state.radarAbort.signal});
    if(state.lastRadarPath===data.path&&state.mapLayers.precipitation)return;
    if(state.mapLayers.precipitation)state.map.removeLayer(state.mapLayers.precipitation);
    state.lastRadarPath=data.path;
    state.mapLayers.precipitation=L.tileLayer(data.tile_template,{opacity:.72,maxNativeZoom:data.max_native_zoom||7,maxZoom:18,tileSize:256,attribution:'Radar: <a href="https://www.rainviewer.com/" target="_blank" rel="noopener">RainViewer</a>'});
    if(document.querySelector('[data-layer="precipitation"]').checked)state.mapLayers.precipitation.addTo(state.map);
    updateLegend();
  }catch(error){
    if(error.name!=="AbortError"){$("mapSource").textContent="Radar indisponível · Open-Meteo permanece ativo";}
  }
}

async function loadMapGrid() {
  if(!state.map)return;
  if(state.mapGridAbort)state.mapGridAbort.abort();
  state.mapGridAbort=new AbortController();
  const center=state.map.getCenter();
  const zoom=state.map.getZoom();
  const span=clamp(12/Math.pow(2,Math.max(0,zoom-5)),0.7,12);
  try{
    const data=await api(`/map-grid?latitude=${center.lat}&longitude=${center.lng}&span=${span}`,{signal:state.mapGridAbort.signal});
    clearDataLayers();
    const grid=data.grid||[];
    state.mapLayers.temperature=renderGridLayer(grid,"temperature_2m");
    state.mapLayers.clouds=renderGridLayer(grid,"cloud_cover");
    state.mapLayers.wind=renderWindLayer(grid);
    if(document.querySelector('[data-layer="temperature"]').checked&&state.mapLayers.temperature)state.mapLayers.temperature.addTo(state.map);
    if(document.querySelector('[data-layer="clouds"]').checked&&state.mapLayers.clouds)state.mapLayers.clouds.addTo(state.map);
    if(document.querySelector('[data-layer="wind"]').checked&&state.mapLayers.wind)state.mapLayers.wind.addTo(state.map);
    updateLegend();
  }catch(error){
    if(error.name!=="AbortError")$("mapSource").textContent="Camadas de modelo temporariamente indisponíveis";
  }
}

function updateMapView() {
  if(!state.map){
    state.map=L.map("map",{zoomControl:true,minZoom:2,maxZoom:18}).setView([state.latitude,state.longitude],7);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:"&copy; OpenStreetMap contributors"}).addTo(state.map);
    state.map.on("moveend",()=>{clearTimeout(state.mapTimer);state.mapTimer=setTimeout(loadMapGrid,500);});
    state.map.on("zoomend",()=>{clearTimeout(state.mapTimer);state.mapTimer=setTimeout(loadMapGrid,500);});
  }else state.map.setView([state.latitude,state.longitude],7,{animate:true});
  if(state.marker)state.marker.remove();
  state.marker=L.marker([state.latitude,state.longitude]).addTo(state.map);
  state.marker.bindPopup(`<b>${state.locationName}</b><br>${state.latitude.toFixed(4)}, ${state.longitude.toFixed(4)}`).openPopup();
  setTimeout(()=>state.map.invalidateSize(),80);
  loadRadarLayer();
  loadMapGrid();
}

function toggleMapLayer(name, enabled) {
  const layer=state.mapLayers[name];
  if(!state.map||!layer)return;
  if(enabled)layer.addTo(state.map); else state.map.removeLayer(layer);
  updateLegend();
}

async function loadIntelligence() {
  clearError(); setLoading(true); setConnection("syncing","SYNCING");
  try{
    const data=await api(`/intelligence?latitude=${encodeURIComponent(state.latitude)}&longitude=${encodeURIComponent(state.longitude)}`);
    renderCurrent(data); renderRisk(data.risk); renderConfidence(data.confidence); renderForecast(data.forecast); renderAlerts(data.risk,data.forecast); renderExplanation(data.explanation); updateMapView();
    $("lastSync").textContent=`LAST SYNC ${new Date().toLocaleTimeString("pt-BR")}`;
    setConnection("operational","OPERATIONAL");
  }catch(error){setConnection("offline","TEMPORARILY OFFLINE");showError(`NIMBO TEMPORARILY OFFLINE — ${error.message||"Não foi possível consultar os dados."}`);}
  finally{setLoading(false);}
}

function closeSearchResults(){ $("locationResults").classList.add("hidden"); $("locationResults").innerHTML=""; }

function renderSearchResults(results) {
  const container=$("locationResults"); container.innerHTML="";
  if(!results.length){container.innerHTML=`<div class="no-results">Nenhum local encontrado</div>`;container.classList.remove("hidden");return;}
  results.forEach(result=>{
    const button=document.createElement("button"); button.type="button"; button.className="location-result"; button.setAttribute("role","option");
    const title=document.createElement("strong"); title.textContent=result.name||"Local";
    const detail=document.createElement("span"); detail.textContent=[result.admin1,result.country].filter(Boolean).join(", ")||"Localização";
    const coords=document.createElement("small"); coords.textContent=`${Number(result.latitude).toFixed(4)}, ${Number(result.longitude).toFixed(4)}`;
    button.append(title,detail,coords);
    button.addEventListener("click",()=>selectLocation(result));
    container.appendChild(button);
  });
  container.classList.remove("hidden");
}

async function searchCityLive(query) {
  const text=query.trim();
  if(text.length<2){
    $("searchStatus").textContent=text.length?"Digite mais 1 letra":"";
    closeSearchResults();
    return;
  }
  if(state.searchAbort)state.searchAbort.abort();
  state.searchAbort=new AbortController();
  $("searchStatus").textContent="...";
  try{
    const data=await api(`/geocode?city=${encodeURIComponent(text)}`,{signal:state.searchAbort.signal});
    renderSearchResults(data.results||[]);
    $("searchStatus").textContent=(data.results||[]).length?"":"×";
  }catch(error){
    if(error.name!=="AbortError"){
      $("searchStatus").textContent="×";
      $("locationResults").innerHTML=`<div class="no-results">Não foi possível pesquisar agora. Verifique a conexão.</div>`;
      $("locationResults").classList.remove("hidden");
    }
  }
}

function scheduleLiveSearch(value){
  clearTimeout(state.searchTimer);
  state.searchTimer=setTimeout(()=>searchCityLive(value),320);
}

function selectLocation(result){
  state.latitude=Number(result.latitude); state.longitude=Number(result.longitude);
  state.locationName=[result.name,result.admin1,result.country].filter(Boolean).join(", ");
  state.selectedLocation=result;
  $("cityInput").value=state.locationName;
  $("latInput").value=state.latitude; $("lonInput").value=state.longitude;
  $("searchStatus").textContent="✓"; closeSearchResults(); clearError(); loadIntelligence();
}

function searchCity(){ scheduleLiveSearch($("cityInput").value); }

function useCoordinates(){
  const lat=Number($("latInput").value), lon=Number($("lonInput").value);
  if(!Number.isFinite(lat)||!Number.isFinite(lon)||lat<-90||lat>90||lon<-180||lon>180){showError("Coordenadas inválidas. Latitude: -90 a 90. Longitude: -180 a 180.");return;}
  state.latitude=lat;state.longitude=lon;state.locationName="Localização por coordenadas";$("cityInput").value="";loadIntelligence();
}

$("refreshButton").addEventListener("click",loadIntelligence);
$("searchButton")?.addEventListener("click",searchCity);
$("coordinateButton").addEventListener("click",useCoordinates);
$("cityInput").addEventListener("input",(event)=>scheduleLiveSearch(event.target.value));
$("cityInput").addEventListener("keydown",(event)=>{if(event.key==="Enter"){event.preventDefault();searchCity();}if(event.key==="Escape")closeSearchResults();});
document.addEventListener("click",(event)=>{if(!event.target.closest(".location-panel"))closeSearchResults();});
document.querySelectorAll(".layer-toggle input").forEach(input=>input.addEventListener("change",()=>toggleMapLayer(input.dataset.layer,input.checked)));

window.addEventListener("load",()=>{$("latInput").value=state.latitude;$(`lonInput`).value=state.longitude;loadIntelligence();});
setInterval(()=>{if(document.visibilityState==="visible")loadIntelligence();},5*60*1000);
